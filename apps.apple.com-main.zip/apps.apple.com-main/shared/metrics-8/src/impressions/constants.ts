export const IMPRESSION_CONTEXT_NAME = 'metrics:impression' as const;
