export function makeProperties(): PackageProperties {
    return {
        clientFeatures: {},
    };
}
